export interface WindowSize {
    width: number;
    height: number;
}