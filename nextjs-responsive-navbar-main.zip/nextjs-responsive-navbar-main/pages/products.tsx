import React from 'react'

type Props = {}

const products = (props: Props) => {
    return (
        <div>products</div>
    )
}

export default products