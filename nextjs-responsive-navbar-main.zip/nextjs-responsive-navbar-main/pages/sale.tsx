import React from 'react'

type Props = {}

const sale = (props: Props) => {
    return (
        <div>sale</div>
    )
}

export default sale