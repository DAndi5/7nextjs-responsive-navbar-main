import React from 'react'

type Props = {}

const profile = (props: Props) => {
    return (
        <div>profile</div>
    )
}

export default profile